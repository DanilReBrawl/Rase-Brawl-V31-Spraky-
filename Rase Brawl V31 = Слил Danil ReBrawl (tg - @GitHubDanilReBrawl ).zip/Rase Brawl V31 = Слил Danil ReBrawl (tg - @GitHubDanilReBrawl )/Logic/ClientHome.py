from Logic.Home.LogicDailyData import LogicDailyData
from Logic.Home.LogicConfData import LogicConfData

class LogicClientHome:

    def encode(self):
        LogicDailyData.encode(self)
        LogicConfData.encode(self)

        self.writeLong(self.player.ID)

        self.writeVInt(2)  # Unknown Array
        self.writeVInt(79) # Notification ID
        self.writeInt(1) # Notification Index
        self.writeBoolean(True) # Notification Read
        self.writeInt(0) # Notification Time Ago
        self.writeString("hacc") # Notification Message Entry
        self.writeVInt(41) # Brawlers Count
        for x in range(41):
            self.writeVInt(16000000 + x) # Brawler ID
            self.writeVInt(1400) # Brawler Trophies
            self.writeVInt(450) # Brawler Trophy Loss
            self.writeVInt(480) # Star Points Gained
        self.writeVInt(81) # Notification ID
        self.writeInt(3) # Notification Index
        self.writeBoolean(True) # Notification Read
        self.writeInt(0) # Notification Time Ago
        self.writeString("Hacc") # Notification Message Entry
        self.writeVInt(0)
        for x in range(0):
            pass

        self.writeVInt(0)  # Unknown

        self.writeUInt8(0) # Unknown
