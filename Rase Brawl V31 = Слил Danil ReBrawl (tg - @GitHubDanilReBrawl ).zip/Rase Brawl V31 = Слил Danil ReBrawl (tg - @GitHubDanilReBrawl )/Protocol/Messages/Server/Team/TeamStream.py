from ByteStream.Writer import Writer
from Protocol.Messages.Server.TeamMessage import TeamMessage

import random

class TeamStream(Writer):
    def __init__(self, client, player):
        super().__init__(client)
        self.player = player
        self.id = 24131

    def encode(self):
        fm = []
        self.writeVInt(0)
        self.writeVInt(self.player.roomsID)
        self.writeVInt(1)
        for i in range(1):
                if self.player.pin in fm:
                	self.writeVint(6)
                else:
                	self.writeVInt(8)
                # StreamEntry::encode
                self.writeVInt(1)
                self.writeVInt(self.player.ctick) # tick
                self.writeVInt(0)
                self.writeVInt(self.player.ID)#Low Id
                self.writeString(self.player.name)
                self.writeVInt(1)
                self.writeVInt(3600) # Age Seconds (TID_STREAM_ENTRY_AGE)
                self.writeVInt(0) # Boolean
                if  not self.player.pin:
                	self.writeDataReference(40, random.randint(0, 11))
                else:
                	self.writeDataReference(40, self.player.pin) # Message Data ID (40 - messages.csv)
                	self.writeBoolean(True) # Target Boolean
                	self.writeString(self.player.name) # Target Name
                	self.writeVInt(1) # ??
                	self.writeVInt(52000000 + self.player.pin) # ScID (eg. 52000319 [trixie colette thanks pin] if message data id is (40, 46) and event 8)
        TeamMessage(self.client, self.player).send()
                
        