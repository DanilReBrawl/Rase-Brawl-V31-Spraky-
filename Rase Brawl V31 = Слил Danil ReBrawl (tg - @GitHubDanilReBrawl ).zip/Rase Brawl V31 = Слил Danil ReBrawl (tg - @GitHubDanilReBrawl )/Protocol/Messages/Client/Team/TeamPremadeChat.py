from ByteStream.Reader import Reader
from Protocol.Messages.Server.Team.TeamStream import TeamStream

class TeamPremadeChat(Reader):
	#14369
	def __init__(self, client, player, initial_bytes):
		super().__init__(initial_bytes)
		self.client = client
		self.player = player
		
	def decode(self):
		print(self.readVInt())
		self.pin = self.readVInt()
		 
	def process(self, db):
		self.player.pin = self.pin
		print(self.pin)
		self.player.ctick += 1
		TeamStream(self.client, self.player).send()