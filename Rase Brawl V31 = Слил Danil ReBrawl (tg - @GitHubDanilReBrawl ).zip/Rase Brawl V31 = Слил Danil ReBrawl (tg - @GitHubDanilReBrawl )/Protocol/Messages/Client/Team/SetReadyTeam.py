from ByteStream.Reader import Reader
from Protocol.Messages.Server.TeamMessage import TeamMessage

class SetReadyTeam(Reader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
      #  self.invites = []
        self.isReady = self.readBool()

    def process(self, db):
        self.player.isReady = self.isReady
        TeamMessage(self.client, self.player).send()